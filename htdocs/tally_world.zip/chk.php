<!DOCTYPE html>
<html>
<body>
<?php



$x = 10; 
$y = 6;

$d= -$x;
$w= "-$y";
echo $d;
echo $w;
echo -$y;
?>   

</body>
</html>