<?php  
include ('sudo_header.php');
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Untitled 2</title>
</head>

<body>

<a href="sudo_welcome.php">HOME</a>

</body>
</html>